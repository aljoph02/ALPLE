[/Script/Engine.WeaponHitDetailInfo]
TotalShootNum=30000
HitNumEveryBodys=40000

[/Script/Engine.SeekAndLockRPGBulletUploadData]
SeekAndLockTarget=AspectRatio_MaintainsYFOV
SeekAndLockStageType=AspectRatio_MaintainsYFOV

[/Script/Engine.ClothPhysicsProperties_Legacy]
GravityScale=90.0f

[/Script/Engine.Server]
Pandora=0.0.0.0
DNS=0.0.0.0
DataClient=0.0.0.0 

[/Script/Engine.BotProtectionServer]
Server=0.0.0.0
Server=disable
BotServet=false
LocalPlayerBotServer=false 

[/Script/Engine.Bot]
BotProtectionServer=false 

[/Script/Engine.PandoraServer]
Pandora=0.0.0.0
PandoraDNS=0.0.0.0
Config=0.0.0.0
ConfigServer=0.0.0.0 

[/Script/Engine.Config]
Config=true 

[WeaponDamageRecord]
TotalDamage=0x1000
HeadShootCount=999
BodyShootCount=0x1000
HandShootCount=$0x888
FootShootCount=AspectRatio_MaintainsYFOV
UniqueHitCount=999
HitDistanceArray=AspectRatio_MaintainsYFOV

[WeaponHitPartCoff]
Head=2.0

[HitPerformData]
IsHeadShot=2.0

[CharacterHistoryData]
HeadBoundBox=AspectRatio_MaintainsYFOV

[WonderfulCutShootDamageData]
DamagePlayerID=AspectRatio_MaintainsYFOV
ShootDamageType=float

[SRecoilInfo]
RecoilCurve=AspectRatio_MaintainsYFOV
BulletPerSwitch=AspectRatio_MaintainsYFOV
RecoilSpeedVertical=false
VerticalRecoilMin=FOV

[ShootVerifyConfig]
ClientMuzzleHeightMax=AspectRatio_MaintainsYFOV

[WeaponCrossHairPerformData]
Crosshair=5
 
[ShootWeaponEffectComponent]
CameraShake=AspectRatio_MaintainsYFOV

[STPointDamageEvent.PointDamageEvent.DamageEvent]
AvatarDamagePosition=false
DamageImpulse=FOV

[GameSetting]
AimAssist=AspectRatio_MaintainsYFOV
SingleShotWeaponShootMode=Max
ActorAnimationSwitch=false
CrossHair=AspectRatio_MaintainsYFOV
LeftHandFire=AspectRatio_MaintainsYFOV
LRShootSniperSwitch=AspectRatio_MaintainsYFOV

[AttackFlow]
BulletDamage=100
BulletSpeed=Max
BulletCost=AspectRatio_MaintainsYFOV
WeaponAimFOV=AspectRatio_MaintainsYFOV
Recoil=AspectRatio_MaintainsYFOV
r.Recoil=AspectRatio_MaintainsYFOV
RecoilMoveX=AspectRatio_MaintainsYFOV
RecoilMoveY=AspectRatio_MaintainsYFOV
AutoAimSpeed=Max
PrinceGaming=69
HitPart=AspectRatio_MaintainsYFOV

[AimFlow]
ShotHitCount=$Value
ShotHeadHitCount=Max
ShotPersonHitCount=AspectRatio_MaintainsYFOV
ShotPersonKillCount=AspectRatio_MaintainsYFOV

[LocalShootHitData]
BulletDown=AspectRatio_MaintainsYFOV
ShootInterval=float
AimFov=AspectRatio_MaintainsYFOV
bulletDamageReduceRatio=Max
AutoAimSpeed=AspectRatio_MaintainsYFOV

[/Script/ShadowTrackerExtra.STExtraBaseCharacter]
ClientHitPartJudgment=0000.01
UseShootVerifyEx=0000.01
                   
[ShootWeaponEntity]
+CVars=RecoveryFactor=100
+CVars=HRecoilFactor=50
+CVars=VRecoilFactor=50
+CVars=DeviationFactor=100
+CVars=WeaponAimYawRate=100
+CVars=CrossHairBurstIncreaseSpeed=100
+CVars=BulletFireSpeed=9999
+CVars=TraceDistance=100
+CVars=ShotGunSpread=100
+CVars=CrossHairInitialSize=100
+CVars=ReloadTime=100
+CVars=ShootInterval=100
+CVars=BulletRange=999
+CVars=BurstShootBulletsNum=100
+CVars=HRecoilFactor=99
+CVars=WeaponAimFOV=99
+CVars=TacticalReloadTimeMagIn=100
+CVars=0ImpactEffectSkipTime=100

[/Script/ShadowTrackerExtra.STExtraBaseCharacter]
HitBoxJudgment=50.0
UseShootVerifyEx=50.0
UseAimAssist=50.0
UseRecoilFaktor=50.0
ClientHitPartJudgment=100.0
UseShootVerifyEx=true
RecoveryFacTor=100.0
HRecoilFactor=100.0
VRecoilFacTor=100.0
DeviationFactor=100.0
BulletFireSpeed=100.0
r.Demage=99
r.HitDemage=99
                
[ShootWeaponBulletBase]
DamageType=float
NoGravityRange=AspectRatio_MaintainsYFOV

[ShootWeaponEntity]
BurstShootBulletsNum=AspectRatio_MaintainsYFOV
BulletFireSpeed=AspectRatio_MaintainsYFOV
MaxBulletNumInOneClip=AspectRatio_MaintainsYFOV
MaxBulletNumInBarrel=false
VolleyShootBulletsNum=Max
shootType=float
WeaponHitPartCoff=Max
DamageRate=AspectRatio_MaintainsYFOV
CrossHairType=5
WeaponAimFOV=AspectRatio_MaintainsYFOV

[PlayerCameraManager_C]
UCameraShake=AspectRatio_MaintainYFOV
                      
[/Script/Engine.GameModePlayerBattleResultData]
TotalDamage=50.0
HitShelterDamage=50.0
ShelterTakeDamage={"99%"}
BuildFlow=3.0
WeaponDamageRecordList=0.5
HitShelterDamage=999
ShelterTakeDamage=5.1

[/Script/Engine.GrenadeDamageRecord]
HitDistanceArray=Max

[/Script/Engine.DamageEvent]
DamageType=0x559

[/Script/Engine.RendererOverrideSettings]
Recoil.heightScale=0

[/Script/Engine.AttackFlow]
BulletDamage=100
BulletSpeed=0x999
BulletCost=0
WeaponAimFOV=100.0
Recoil=0
RecoilMoveX=0
RecoilMoveY=0
AutoAimSpeed=0.1
HitPart=5

[/Script/Engine.AimFlow]
ShotHitCount=$Value
ShotHeadHitCount={"120")
ShotPersonHitCount={1}
ShotPersonKillCount={1}
                       
[/Script/Engine.RendererSettings]
ClientHitPartJudgment=0

[/Script/Engine.Basic]
T.SpeedFire=2
T.Damage=5
T.AimAssist=9
T.LeftHandFire=3
T.CameraShake=0
T.BulletSpeed=2
T.BulletDamage=3
T.HitNumEveryBodys=5
T.Recoil=5

[/Script/Engine.RecoilInfo]
SwitchOnTime=0.f
ShootSightReturn=0.f
VRecoilFactor=0
HRecoilFactor=0

[/Script/Engine.RecoilInfo]
RecoilCurve=2
BulletPerSwitch=0.5
RecoilSpeedVertical=999
VerticalRecoilMin=0
              
[/Script/Engine.ShootWeaponEffectComponent]
CameraShake=false

[/Script/Engine.GameSetting]
AimAssist=50.0
SingleShotWeaponShootMode=3.0
ActorAnimationSwitch=false
CrossHair=5
LeftHandFire=AspectRatio_MaintainsYFOV
LRShootSniperSwitch=AspectRatio_MaintainsYFOV

[/Script/Engine.AttackFlow]
BulletDamage=100
BulletSpeed=0x999
BulletCost=AspectRatio_MaintainsYFOV
WeaponAimFOV=AspectRatio_MaintainsYFOV
Recoil=0
RecoilMoveX=0
RecoilMoveY=0
AutoAimSpeed=0x999
HitPart=5

[Script/Engine/SeekAndLockRPGBulletUploadData]
SeekAndLockTarget=0x999

[Script/Engine/PlayerState]
ShootWeaponShotNum=5.0
ShootWeaponShotAndHitPlayerNum=5.5
ShootWeaponShotAndHitPlayerNumNoAI={"5"}
ShootWeaponShotHeadNum={"99%"}
HeadShotNum=9.0f
DamageAmount=99
               
[Script/Engine/WeaponDamageRecord]
HitDistanceArray={"5.0f"}
WeaponId=0
TotalDamage={"99%"}
T.FireCount=3.0
T.HeadShootCount=3.0
T.BodyShootCount=5

[Script/Engine/WeaponReport]
FireCount=5
HitCount=9
TotalDamage=999
HeadShootCount=9

[Script/Engine/HitFlow]
Damage={"99%"}

AljoPH